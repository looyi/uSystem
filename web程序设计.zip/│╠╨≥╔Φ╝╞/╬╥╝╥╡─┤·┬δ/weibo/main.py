#!/usr/bin/env python
# -*- coding: utf-8 -*-
import os.path
import re
import unicodedata

import pymongo
import json

import tornado.httpserver
import tornado.ioloop
import tornado.options
import tornado.web

from tornado.options import define, options
define("port", default=8888, help="run on the given port", type=int)


class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", HomeHandler),
            (r"/twitter/([^/]+)", TwitterHandler),
            (r"/login", LoginHandler),
            (r"/logout", LogoutHandler),
        ]
        settings = dict(
            blog_title=u"Tornado Blog",
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            #xsrf_cookies=True,
            cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
            login_url="/login",
            debug=True,
        )
        tornado.web.Application.__init__(self, handlers, **settings)

        # Have one global connection to the blog DB across all handlers
        conn = pymongo.Connection("localhost", 27017)
        self.db = conn.twitterDB.userSets


class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.db

    def get_current_user(self):
        return self.get_secure_cookie("user")


class HomeHandler(BaseHandler):
    def get(self):
        all = self.db.find()
        if all:
            del all["_id"]
            #self.render("home.html", all=all)


class TwitterHandler(BaseHandler):
    def get(self, user):
        user_info = self.db.find_one({"name": self.current_user})
        if not user_info:
            self.write('<html><body>Please <a href="/login">Sign in</a> first.</body></html>')
            return

        user_info = self.db.find_one({"name": user})
        twitters = user_info['twitters']
        for twi in twitters:
            twi['name'] = user_info['name']

        friends = user_info['friends']
        for fri in friends:
            fri_info = self.db.find_one({"name": fri})
            for twi in fri_info['twitters']:
                twi['name'] = fri_info['name']
                twitters.append(twi)
        twitters = sorted(twitters, key=lambda k: k["time"])
        print twitters
        self.render("twitter.html", info=user_info, twitters=twitters)


class LoginHandler(BaseHandler):
    def get(self):
        self.write('<html><body><form action="/login" method="post">'
                   'User: <input type="text" name="user">'
                   'Password: <input type="password" name="password">'
                   '<input type="submit" value="Sign in">'
                   '</form></body></html>')

    def post(self):
        usr = self.get_argument("user")
        pwd = self.get_argument("password")

        user_info = self.db.find_one({"name": usr})
        if not user_info:
            self.write("No User!")
            return
        if user_info['password'] != pwd:
            self.write("Wrong Password!")
            return
        self.set_secure_cookie("user", usr)
        self.redirect("/twitter/" + usr)
        #self.redirect("/login")


class LogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("user")
        self.redirect("/login")



def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()


if __name__ == "__main__":
    main()
