$( document ).ready(function() {
			//Fetch Users' Comments based on the Twitter Clicked
			$( "div.twitter a" ).click(function(event) {
				var ancestor = $(this).parents( "div.twitter" );
				ancestor.find(".twitterComment").show();
				var username = ancestor.find(".username").text();
				var twitterDate = ancestor.find(".twitterDate").text();
				// console.log(username);
				$.ajax({
					url: "/comment",
					type: "GET",
					dataType: "json",
					data: {"username": username,
						   "twitterDate": twitterDate},
				    success: function( json ) {
				    	// console.log(json.length);
				    	for (var i = 0; i < json.length; i++) {
				    		// console.log(json[i].comment_content);
				    		var $newElement = $("<div class=\"userComment\">"
				    			+ "<span class=\"commentUser\">" + json[i].comment_by + "</span>"
				    			+ "<span class=\"commentContent\">" + json[i].comment_content + "</span>"
				    			+ "<span class=\"commentDate\">" + json[i].comment_date + "</span>"
				    			+ "</div>");
				    		$newElement.insertAfter(ancestor.find(".commentInput"));
				    	}
				    },
				    error: function( xhr, status ) {
				    	alert( "Sorry, there was a problem!" );
				    }
				});		
			});

            //Submit Comment
            $(".commentInput button").click(function(event) {
            	var ancestor = $(this).parents( "div.twitter" );
            	var twitterOwnerUsername = ancestor.find(".username").text();
				var twitterDate = ancestor.find(".twitterDate").text();
				var commentContent = ancestor.find("input").val();
				$.ajax({
					url: "/comment",
					type: "POST",
					dataType: "json",
					data: {"twitterOwnerUsername": twitterOwnerUsername,
						   "twitterDate": twitterDate,
						   "commentContent": commentContent},
				    success: function( json ) {
				    	// console.log(json);
				    	var $newElement = $("<div class=\"userComment\">"
				    		+ "<span class=\"commentUser\">" + json.comment_by + "</span>"
				    		+ "<span class=\"commentContent\">" + json.comment_content + "</span>"
				    		+ "<span class=\"commentDate\">" + json.comment_date + "</span>"
				    		+ "</div>");
				    	$newElement.insertAfter(ancestor.find(".commentInput"));
				    },
				    error: function( xhr, status ) {
				    	alert( "Sorry, there was a problem!" );
				    }
				});
				ancestor.find("input").val("");	
            });
		});