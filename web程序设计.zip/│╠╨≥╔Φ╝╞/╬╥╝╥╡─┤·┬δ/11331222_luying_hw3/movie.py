import os.path

import tornado.ioloop
import tornado.web

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("main.html", error=False)

    def post(self):
		self.redirect(self.get_argument("movie"))

class MovieHandler(tornado.web.RequestHandler):
    def get(self, movie):
		if os.path.isdir("static/"+movie):
			with open("static/"+movie+"/info.txt", "r") as f:
				info = f.readlines()
			with open("static/"+movie+"/generaloverview.txt", "r") as f:
				overview = f.readlines()
			
			reviews = []
			items = os.listdir("static/"+movie)
			for item in items:
				if "review" in item:
					f = open("static/"+movie+"/"+item,"r")
					reviews.append(f.readlines())
			self.render("movie.html", movie=movie, info=info, overview=overview, reviews=reviews)
		else:
			self.render("main.html", error=True)		

settings = {
	"static_path": os.path.join(os.path.dirname(__file__), "static"),
	"template_path": os.path.join(os.path.dirname(__file__), "template"),
    "debug": True,
}

application = tornado.web.Application([
	(r"/", MainHandler),
	(r"/([A-Za-z0-9]+)", MovieHandler),
], **settings)

if __name__ == "__main__":
	application.listen(8888)
	tornado.ioloop.IOLoop.instance().start()