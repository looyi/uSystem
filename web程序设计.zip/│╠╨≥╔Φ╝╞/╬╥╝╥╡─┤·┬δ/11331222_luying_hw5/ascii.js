var frames;
var timer;
var cur;

window.onload = function() {
	$("start").onclick = start;
	$("stop").onclick = stop;
};

function animationSelected() {
	if ($("animation").value == "Custom") {
		$("displayarea").value = "(～￣▽￣)～ \n" +
								 "=====\n" +
								 "～(￣▽￣～)\n" +
								 "=====\n" +
								 "～(￣▽￣～)(～￣▽￣)～\n";

		frames = $("displayarea").value.split("=====\n");
	} else {
		$("displayarea").value = ANIMATIONS[$("animation").value];
		frames = $("displayarea").value.split("=====\n");
	};
}

function sizeSelected() {
	var size;
	if ($("size1").checked) {
		size = $("size1").value;
	} else if ($("size2").checked) {
		size = $("size2").value;
	} else if ($("size3").checked) {
		size = $("size3").value;
	};

	$("displayarea").style.fontSize = size;
}

function start() {
	frames = null;
	timer = null;
	cur = 0;

	sizeSelected();

	if ($("animation").value != 'Blank') {
		animationSelected();
	};

	$("start").disabled = "disabled";
	timer = setInterval(display, 200);
}

function stop() {
	clearInterval(timer);
	timer = null;
	cur = 0;

	$("displayarea").value = frames.join("=====\n");
	$("start").disabled = "";
}

function display() {
	if (cur < frames.length) {
		$("displayarea").value = frames[cur];
		cur ++;
	} else {
		$("displayarea").value = frames[0];
		if (frames.length > 0) {
			cur = 1;
		} else {
			cur = 0;
		};
	};
}