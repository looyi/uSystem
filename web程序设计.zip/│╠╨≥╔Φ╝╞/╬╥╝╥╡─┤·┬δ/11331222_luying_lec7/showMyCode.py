#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os, sys

def show():
	filename = os.path.realpath(__file__)
	print filename
	try:
		f = open(filename, 'r')
	except:
		print("Unexpected error:", sys.exc_info()[0], sys.exc_info()[1])
	lines = f.readlines()
	for line in lines:
		line = line.strip('\n')
		print(str(line))
	f.close()

if __name__ == '__main__':
	show()