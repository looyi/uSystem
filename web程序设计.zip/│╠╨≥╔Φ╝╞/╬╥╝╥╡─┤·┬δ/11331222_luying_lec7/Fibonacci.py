# Fibonacci series:
# the sum of two elements defines the next
a, b = 0, 1
fib = [a]
while b < 50:
    fib.append(b)
    a, b = b, a+b

fib.reverse()
for n in fib:
	print n,