#coding=utf-8

import re
import string

class WordParser:
	def __init__(self):
		self.words = {}
		self.counts = {}
	
	def read(self, filename):
		try:
			f = open(filename, 'r')
		except:
			return ('Cannot open this file!\n')
		
		for line in f:
			word = line.strip()
			if word in self.words:
				self.words[word] += 1
			else:
				self.words[word] = 1
		f.close()

	def count(self):
		self.counts = dict.fromkeys(self.words.values(), [])
		for w, c in self.words.items():
			self.counts[c].append(w)
		print self.counts

	def write(self, filename):
		words = sorted(self.words.iteritems(), key=lambda k: k[1], reverse=True)
		with open(filename, 'w') as f:
			for w, c in words:
				count = "count " + str(c) + ": ['" + str(w) + "']\n"
				f.write(count)

if __name__ == '__main__':
	wordParser = WordParser()
	wordParser.read("input.txt")
	wordParser.count()
	wordParser.write("results.txt")