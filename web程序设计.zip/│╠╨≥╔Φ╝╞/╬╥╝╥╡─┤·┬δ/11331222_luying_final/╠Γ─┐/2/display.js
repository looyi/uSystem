window.onload = function () {
  var isPlay = false;
  var startButton = document.getElementById('start');
  var stopButton = document.getElementById('stop');
  var character = document.getElementById('content');
  var timer = null;
  var increase = true;

  function initial () {
    initialButtonsWithFlag(isPlay);
    bindEventToButtons();
  }

  function initialButtonsWithFlag () {
    if (isPlay) {
      disableStartButton();
      enableStopButtion();
    } else {
      disableStopButtion();
      enableStartButton();
    }
  }

  function disableStartButton () {
    startButton.disabled = true
  }

  function enableStopButtion () {
    stopButton.disabled = false;
  }

  function disableStopButtion () {
    stopButton.disabled = true;
  }

  function enableStartButton () {
    startButton.disabled = false;
  }

  function bindEventToButtons () {
    startButton.onclick = startChangeFontSize;
    stopButton.onclick = stopChangeFontSize;
  }

  function startChangeFontSize () {
    enableStopButtion();
    disableStartButton();
    changeFontSize();
    timer = setInterval(changeFontSize, 1000);
  }

  function stopChangeFontSize () {
    enableStartButton();
    disableStopButtion();
    clearInterval(timer);
  }

  function changeFontSize () {
    var fontSize = character.style.fontSize;
    fontSize = fontSize.slice(0, -2);
    fontSize = parseInt(fontSize);
    if (increase) {
      fontSize += 50;
    } else {
      fontSize -= 50;
    }

    if (fontSize >= 500) {
      increase = false;
    }

    if (fontSize <= 50) {
      increase = true;
    }

    character.style.fontSize = "" + fontSize + "px";
  }

  initial();

}
