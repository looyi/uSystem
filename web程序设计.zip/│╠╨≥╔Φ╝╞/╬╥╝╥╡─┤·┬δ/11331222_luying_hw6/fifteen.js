var puzzlediv;
var emptyspaceX;
var emptyspaceY;

window.onload = function() {
	var puzzlearea = document.getElementById('puzzlearea');
	puzzlediv = puzzlearea.getElementsByTagName('div');

	emptyspaceX = "300px";
	emptyspaceY = "300px";

	for (var i = 0; i < puzzlediv.length; i++) {
		puzzlediv[i].className = "puzzlepiece";
		puzzlediv[i].style.left = i%4*100 + 'px';
		puzzlediv[i].style.top = parseInt(i/4)*100 + 'px';
		puzzlediv[i].style.backgroundPosition = '-' + puzzlediv[i].style.left + ' ' + '-' + puzzlediv[i].style.top;

		puzzlediv[i].onmouseover = function() {
			if (canMove(parseInt(this.innerHTML))) {
				this.style.border = "2px solid red";
				this.style.color = "#006600";
			};
		};

		puzzlediv[i].onmouseout = function() {
			this.style.border = "2px solid black";
			this.style.color = "#000000";
		};

		puzzlediv[i].onclick = function() {
			if (canMove(parseInt(this.innerHTML))) {
				slide(this.innerHTML);

				if (isFinish()) {
					alert("Win!");
				};

				return;
			};
		};
	};

	var shufflebutton = document.getElementById('shufflebutton');
	shufflebutton.onclick = function() {
		for (var i = 0; i < 10; i++) {
			for (var i = 0; i < puzzlediv.length; i++) {
				if (canMove(parseInt(puzzlediv[i].innerHTML))) {
					if (Math.random() < 0.5) {
						slide(puzzlediv[i].innerHTML);
					};
				};
			};
		};
	};

};

function canMove(pos) {
	var i = pos - 1;
	var x = parseInt(emptyspaceX);
	var y = parseInt(emptyspaceY);

	if ((parseInt(puzzlediv[i].style.left) + 100 == x && parseInt(puzzlediv[i].style.top) == y) ||
		(parseInt(puzzlediv[i].style.left) - 100 == x && parseInt(puzzlediv[i].style.top) == y) ||
		(parseInt(puzzlediv[i].style.top) + 100 == y && parseInt(puzzlediv[i].style.left) == x) ||
		(parseInt(puzzlediv[i].style.top) - 100 == y && parseInt(puzzlediv[i].style.left) == x)) {
		return true;
	};

	return false;
}

function slide(pos) {
	var x = puzzlediv[pos-1].style.left;
	puzzlediv[pos-1].style.left = emptyspaceX;
	emptyspaceX = x;

	var y = puzzlediv[pos-1].style.top;
	puzzlediv[pos-1].style.top = emptyspaceY;
	emptyspaceY = y;
}

function isFinish() {
	var flag = true;
	for (var i = 0; i < puzzlediv.length; i++) {
		if (parseInt(puzzlediv[i].style.left) != i%4*100 || 
			parseInt(puzzlediv[i].style.top) != parseInt(i/4)*100) {
			flag = false;
			break;
		};
	};

	return flag;
}