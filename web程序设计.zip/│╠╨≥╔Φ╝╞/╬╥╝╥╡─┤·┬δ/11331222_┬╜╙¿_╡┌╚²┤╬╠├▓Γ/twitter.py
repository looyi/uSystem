#!/usr/bin/env python

import os.path
import re
import unicodedata

import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.options

from tornado.options import define, options

import pymongo
import json

define("port", default=8888, help="run on the given port", type=int)

class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/twitter/(\w+)", TwitterHandler),
            (r"/login", LoginHandler),
            (r"/logout", LogoutHandler),
        ]
        settings = dict(
            blog_title=u"Twitter",
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
            login_url="/login",
            debug=True,
        )
        tornado.web.Application.__init__(self, handlers, **settings)

        # Have one global connection to the blog DB across all handlers
        self.conn = pymongo.Connection("localhost", 27017)
        self.db = self.conn.twitterDB.userSets

class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.db

    def get_current_user(self):
        return self.get_secure_cookie("user")

class TwitterHandler(BaseHandler):
    def get(self, username):
        user_id = self.db.find_one({"name": self.current_user})
        if not user_id:
            self.write('<html><body>Please <a href="/login">Sign in</a> first.</body></html>')
            return
        
        twitters = user_id['twitters']
        for t in twitters:
            t['name'] = user_id['name']

        friends = user_id['friends']
        for f in friends:
            friend_id = self.db.find_one({"name": f})
            for t in friend_id['twitters']:
                t['name'] = f
                twitters.append(t)

        jsonTwi = json.dumps(twitters)
        self.write(jsonTwi)

class LoginHandler(BaseHandler):
    def get(self):
        self.write('<html><body><form action="/login" method="post">'
                   'User: <input type="text" name="user">'
                   'Password: <input type="password" name="password">'
                   '<input type="submit" value="Sign in">'
                   '</form></body></html>')

    def post(self):
        usr = self.get_argument("user")
        pwd = self.get_argument("password")

        user_id = self.db.find_one({"name": usr})
        if user_id['password'] == pwd:
            self.set_secure_cookie("user", usr)
            self.write("ok!")
            self.redirect("/twitter/" + usr)

        self.redirect("/login")

class LogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("user")
        self.write("logout!!!")
        self.redirect("/login")

def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()


if __name__ == "__main__":
    main()