#!/usr/bin/env python

import os.path
import re
import unicodedata

import markdown
import tornado.httpserver
import tornado.ioloop
import tornado.web
import tornado.options

from tornado.options import define, options

import database

define("port", default=8888, help="run on the given port", type=int)

class Application(tornado.web.Application):
    def __init__(self):
        handlers = [
            (r"/", HomeHandler),
            (r"/(\w+)/Charles/[0-9]+", BlogHandler),
            (r"/compose", ComposeHandler),
            (r"/login", LoginHandler),
            (r"/logout", LogoutHandler),
        ]
        settings = dict(
            blog_title=u"My Blog",
            template_path=os.path.join(os.path.dirname(__file__), "templates"),
            static_path=os.path.join(os.path.dirname(__file__), "static"),
            xsrf_cookies=True,
            cookie_secret="61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
            login_url="/login",
            autoescape=None,
            debug=True,
        )
        tornado.web.Application.__init__(self, handlers, **settings)

        self.db = database.DataBase()
        self.db.read("static/data")


class BaseHandler(tornado.web.RequestHandler):
    @property
    def db(self):
        return self.application.db
    
    def get_current_user(self):
        return self.get_secure_cookie("user")


class HomeHandler(BaseHandler):
    def get(self):
        #for i in range(5):
        #    entries = self.db.get_blog(i)
        entries = self.db.blogs
        self.render("home.html", entries=entries)     


class BlogHandler(BaseHandler):
    def get(self, author_name):
        blog = self.db.get_blog(0)
        comments = self.db.get_comments(0)
        if not blog: raise tornado.web.HTTPError(404)
        self.render("blog.html", blog=blog, comments=comments)


class ComposeHandler(BaseHandler):
    @tornado.web.authenticated
    def get(self):
        id = self.get_argument("id", None)
        entry = None
        if id:
            entry = self.db.get_blog(id)
        self.render("compose.html", entry=entry)

    @tornado.web.authenticated
    def post(self):
        id = self.get_argument("id", None)
        title = self.get_argument("title")
        text = self.get_argument("markdown")
        html = markdown.markdown(text)
        if id:
            entry = self.db.get_blog(id)
            if not entry: raise tornado.web.HTTPError(404)
            slug = entry.slug
            # TODO
        else:
            slug = unicodedata.normalize("NFKD", title).encode(
                "ascii", "ignore")
            slug = re.sub(r"[^\w]+", " ", slug)
            slug = "-".join(slug.lower().strip().split())
            if not slug: slug = "entry"
            while True:
                e = self.db.get_blog(slug)
                if not e: break
                slug += "-2"
            # TODO
        self.redirect("/entry/" + slug)


class LoginHandler(BaseHandler):
    def get(self):
        self.render("login.html")

    def post(self):
        usr = self.get_argument("user")
        pwd = self.get_argument("password")
        if self.db.is_user(usr, pwd):
            self.set_secure_cookie("user", self.get_argument("user"))
            self.redirect("/")
        self.redirect("/login")


class LogoutHandler(BaseHandler):
    def get(self):
        self.clear_cookie("user")
        self.write("logout!!!")


def main():
    tornado.options.parse_command_line()
    http_server = tornado.httpserver.HTTPServer(Application())
    http_server.listen(options.port)
    tornado.ioloop.IOLoop.instance().start()


if __name__ == "__main__":
    main()
