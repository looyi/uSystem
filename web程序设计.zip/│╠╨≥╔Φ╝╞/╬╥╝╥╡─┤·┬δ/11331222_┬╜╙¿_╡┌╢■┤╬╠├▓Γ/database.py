#! /usr/bin/env python
# -*- coding: utf-8 -*-

import os.path

class DataBase:
	def __init__(self):
		self.users = {}
		self.blogs = []
		self.comments = []
	
	def read(self, path):
		if os.path.isfile(path + "/users.txt"):
			with open(path + "/users.txt", "r") as f:
				user_list = f.readlines()
				for item in user_list:
					usr, pwd = item.split(',', 1)
					usr = usr.strip()
					pwd = pwd.strip()
					self.users[usr] = pwd
		
		if os.path.isfile(path + "/comments.txt"):
			with open(path + "/comments.txt", "r") as f:
				comment_list = f.readlines()
				comments = []
				for item in comment_list:
					usr, day, cmt = item.split('|', 2)
					comments.append([usr, day, cmt])
				self.comments.append(comments)
					
		if os.path.isfile(path + "/blog.txt"):
			with open(path + "/blog.txt", "r") as f:
				blog_list = f.readlines()
				blog = []
				for item in blog_list:
					key, val = item.split(':', 1)
					blog.append(val)
				self.blogs.append(blog)
	
	
	def is_user(self, usr, pwd):
		if usr in self.users.keys():
			if self.users[usr] == pwd:
				return True
		else:
			return False
	
	
	def blogs(self):
		return self.blogs
	
	
	def get_blog(self, id):
		return self.blogs[id]
	
	
	def get_comments(self, id):
		return self.comments[id]
		

if __name__ == "__main__":
	import database
	d = database.DataBase()
	d.read("static/data")
	print d.is_user("admin", "12345")
	print d.is_user("user", "123")
	print d.get_blog(0)
	print d.get_comments(0)
	
