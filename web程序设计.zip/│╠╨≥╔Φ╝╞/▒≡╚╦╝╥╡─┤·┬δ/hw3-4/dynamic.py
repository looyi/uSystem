import tornado.ioloop
import tornado.web
import os

class MainHandler(tornado.web.RequestHandler):
    def get(self):
        self.write("hello")

class EntryHandler(tornado.web.RequestHandler):
    def get(self, slug):
        items = os.listdir("static/moviefiles")
        if slug in items:
            path = "static/moviefiles/" + slug
            f = open(path + "/info.txt", "r")
            list = f.readlines()
            general_path = path + "/generaloverview.png"
            f = open(path + "/generaloverview.txt", "r")
            list2 = f.readlines()
            files = os.listdir("static/moviefiles/" + slug)
            reviews = []
            for item in files:
                if "review" in item:
                    f = open(path + "/" + item, "r")
                    r = f.readlines()
                    reviews.append(r)
            self.render("skeleton.html", movie=list[0][:-1], year=list[1][:-1],
                        percent=list[2][:-1],review=list[3],general_path = general_path,
                        overview = list2, reviews=reviews)
        else:
            raise tornado.web.HTTPError(404)

class BuyHandler(tornado.web.RequestHandler):
    def get(self):
        self.render("buyagrade.html")

    def post(self):
        name = self.get_argument("name")
        section = self.get_argument("section")
        no = self.get_argument("card_number")
        cc = self.get_argument("cc")

        if cc != "" and no != "" and section != "" and name != "" :
            files = os.listdir("./")
            print files
            
            if "loginfo.txt" in files:
                f = open("loginfo.txt", "r")
                list = f.readlines()
            else:
                list = []
            f = open("loginfo.txt", "a")
            f.write(name + ";" + section + ";" + no + ";" + cc + "\n")
            self.render("buyagradepost.html",
                        name=name,section=section,no=no,cc=cc,list=list)
        else:
            self.render("buyagradealarm.html")

settings = {
    "static_path": os.path.join(os.path.dirname(__file__), "static"),
    "cookie_secret": "61oETzKXQAGaYdkL5gEmGeJJFuYh7EQnp2XdTP1o/Vo=",
    "login_url": "/login",
    "debug": True,
    "autoescape": None,
}

application = tornado.web.Application([
                                       (r"/", MainHandler),
                                       (r"/movies/([^/]+)", EntryHandler),
                                       (r"/public/buyagrade", BuyHandler),
                                       ], **settings)

if __name__ == "__main__":
	application.listen(8888)
	tornado.ioloop.IOLoop.instance().start()

